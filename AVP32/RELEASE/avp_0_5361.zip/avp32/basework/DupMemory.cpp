#include "stdafx.h"
#include <dupmem/dupmem.h>

void* DupAlloc(unsigned size, BOOL static_)
{
	return new char[size];
}

void  DupFree(void* ptr)
{
	delete ptr;
}
