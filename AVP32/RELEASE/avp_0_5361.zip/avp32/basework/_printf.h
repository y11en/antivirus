////////////////////////////////////////////////////////////////////
//
//  _PRINTF.H
//  Printf definition 
//  General purpose
//  Alexey de Mont de Rique [graf@avp.ru], Kaspersky Labs. 1999
//  Copyright (c) Kaspersky Labs.
//
////////////////////////////////////////////////////////////////////

#ifndef ___PRINTF_H
#define ___PRINTF_H

int Printf (const char *msg, ...);

#endif//___PRINTF_H