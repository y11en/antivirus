#ifdef GDATA

#include <vdw.h>
#include "FSAVP.h"
#include "msglog.h"
#include "FSBase.h"

int dummy(int ret){return ret;}

#endif //GDATA