#include "stdafx.h"

#if defined(__LINUX__)
	#include <sys/stat.h>
	#include <unistd.h>
	#include <string.h>

	#if defined USE_FM
		#include "fpiapi.h"
		#include "fpi_ids.h"
	#endif
	#include "../../avp32/typedef.h"
#elif defined (__unix__)
	#include <sys/stat.h>
	#include <unistd.h>
	#include <string.h>
#endif

#include <_avpio.h>
#include "tfiledata.h"
#include <dupmem/dupmem.h>
#include <scanapi/baseapi.h>

#ifndef SEEK_SET
#include <stdio.h>
#endif

#ifdef __MWERKS__
	#include <string.h>
#endif	

#ifdef INTERLOCK
extern "C" LONG InMyOpenClose;
#endif

#ifdef MULTITHREAD
CRITICAL_SECTION csCacheData;
#else
#define EnterCriticalSection(x) ;
#define LeaveCriticalSection(x) ;
#define InitializeCriticalSection(x) ;
#define DeleteCriticalSection(x) ;
#endif

#define CSECT_SIZE 0x1000
#define CDIRTY 0x00000001
#define CSECT_MASK (~(CSECT_SIZE-1))
#define CSECTORS 32

#ifdef FPIAPI_VER_MAJOR
#if FPIMAX_READLENGTH < CSECT_SIZE
#error "FPIMAX_READLENGTH < CSECT_SIZE !!!"
#endif
extern LPFPIFILEIOFNTABLE	FPI_IO;
extern DWORD open_reserved_flag;
extern FPICONTAINERHANDLE fpiParentGet(LPCSTR filename_);
extern BOOL _QueryAbort(DWORD refdata_);
#endif//FPIAPI_VER_MAJOR

#ifdef USE_WIN32_API
#define AVPDEF(x) x
#else 
#define AVPDEF(x) Avp##x
#endif

static TFileData * TFileData_New()
{
    TFileData * fd = new TFileData;
    if (!fd)   return 0;

    memset(fd, 0, sizeof(TFileData));
	fd->Signature=0xfffefffe;
    return fd;
}

static void TFileData_Remove(TFileData * fd)
{
	if(	fd->Signature != 0xfffefffe)
	{
		return;
	}
	fd->Signature=0;
    delete fd;
}
static BOOL TFileData_IsValid(TFileData * fd)
{
	if(fd == (TFileData *)INVALID_HANDLE_VALUE
	|| fd == 0
	|| fd->Signature != 0xfffefffe
	|| fd->Handle == INVALID_HANDLE_VALUE
	|| fd->Handle == 0
	){
		return FALSE;
	}
	return TRUE;
}

typedef struct CACHE_TAGs
{
    DWORD sector;                 /* sector in cache and dirty bit */
    TFileData* tFile;
	BYTE* data;
	DWORD count;
    struct CACHE_TAGs *next;      /* next block in LRU list */
    struct CACHE_TAGs *prev;      /* prev block in LRU list */
}  tCACHE_TAG ;

typedef struct CACHE_DATAs
{
	tCACHE_TAG* Head;
	tCACHE_TAG* Tail;
    tCACHE_TAG  TagArray[CSECTORS];
    BYTE CacheData[CSECTORS*CSECT_SIZE];
#ifdef _DEBUG
    DWORD CacheHits;
    DWORD CacheMisses;
#endif
}  tCACHE_DATA;

tCACHE_DATA* CACHE_DATA=0;

static void MoveBlockToHead(tCACHE_TAG *cblock)
{
	if(cblock->prev)
	{
		if(cblock->next)
			cblock->next->prev = cblock->prev;
		else 
			CACHE_DATA->Tail = cblock->prev;
		cblock->prev->next = cblock->next;      /* remove block from block list */
		cblock->next = CACHE_DATA->Head;        /* insert current block at head */
		cblock->next->prev = cblock;
		cblock->prev = 0;
		CACHE_DATA->Head = cblock;
	}
}

static void MoveBlockToTail(tCACHE_TAG *cblock)
{
	if(cblock->next)
	{
		if(cblock->prev)
			cblock->prev->next = cblock->next;
		else 
			CACHE_DATA->Head = cblock->next;
		cblock->next->prev = cblock->prev;      /* remove block from block list */
		cblock->prev = CACHE_DATA->Tail;        /* insert current block at tail */
		cblock->prev->next = cblock;
		cblock->next = 0;
		CACHE_DATA->Tail = cblock;
	}
}

static void *FileSector(TFileData* tFile, DWORD sector, DWORD* count)
{
    tCACHE_TAG *cblock;
    BYTE *data;
    int dirty;
	BOOL ok =1;
	BOOL hit=0;
	DWORD seek=0;
	
	if(count)*count=0;
	if(!CACHE_DATA || tFile==NULL) return NULL;
    dirty = (int)(sector & CDIRTY);
    sector &= CSECT_MASK;

	EnterCriticalSection(&csCacheData);
	cblock = CACHE_DATA->Head;  /* assume that first block is HEAD of list */

    while ( cblock )
    {
		if( cblock->tFile == NULL )
			break;

        if ((cblock->tFile == tFile ) &&
			(cblock->sector & CSECT_MASK) == sector )
		{
			hit=1;
			break;
		}
        cblock = cblock->next;
    }
	if(!cblock)cblock = CACHE_DATA->Tail;
	MoveBlockToHead(cblock);

    data = cblock->data;

#ifdef _DEBUG
    if(hit) CACHE_DATA->CacheHits++;
	else    CACHE_DATA->CacheMisses++;
#endif

    if ( !hit )  /* cache miss */
    {
		/* check old content for modification */
		if(cblock->tFile 
			&& (cblock->sector & CDIRTY)
			&& (cblock->tFile->CurrLen > (cblock->sector & CSECT_MASK)))   
        {
			UINT size=cblock->tFile->CurrLen - (cblock->sector & CSECT_MASK);
			if(size>CSECT_SIZE) size=CSECT_SIZE;

			switch(cblock->tFile->HandleFS)
			{
			case FS_WIN32:
				seek=AVPDEF(SetFilePointer)(cblock->tFile->Handle,cblock->sector & CSECT_MASK,0,SEEK_SET);
				if(seek==(DWORD)-1) 
					cblock->tFile->WriteBackFailed=1;
				if(! AVPDEF(WriteFile)(cblock->tFile->Handle,data,size,&cblock->count,0))
					cblock->tFile->WriteBackFailed=1;
				break;
#ifdef PRAGUE
			case FS_PRAGUE:
				if(! CALL_IO_SeekWrite((hIO)cblock->tFile->Handle,&cblock->count,cblock->sector & CSECT_MASK,data,size))
					cblock->tFile->WriteBackFailed=1;
				break;
#endif//PRAGUE
#ifdef FPIAPI_VER_MAJOR
			case FS_FPI:
				seek=FPI_IO->fFnSetPos((FPIFILEHANDLE)cblock->tFile->Handle,cblock->sector & CSECT_MASK,SEEK_SET);
				if(seek==(DWORD)-1)
					cblock->tFile->WriteBackFailed=1;
				if(! FPI_IO->fFnWrite((FPIFILEHANDLE)cblock->tFile->Handle,data,size,&cblock->count))
					cblock->tFile->WriteBackFailed=1;
				_QueryAbort(0);
				break;
#endif//FPIAPI_VER_MAJOR
			default:
				ok =0;
				break;
			}
        }
		BOOL readed=0;
		switch(tFile->HandleFS)
		{
		case FS_WIN32:
			seek=AVPDEF(SetFilePointer)(tFile->Handle,sector & CSECT_MASK,0,SEEK_SET);
			if(seek==(DWORD)-1){
				ok=0;
			}
			readed = AVPDEF(ReadFile)(tFile->Handle,data,CSECT_SIZE,&cblock->count,0);
			break;
#ifdef PRAGUE
		case FS_PRAGUE:
			readed = PR_SUCC(CALL_IO_SeekRead((hIO)tFile->Handle,&cblock->count,sector & CSECT_MASK,data,CSECT_SIZE));

			if(PR_FAIL(CALL_SYS_SendMsg((hIO)tFile->Handle,pmc_PROCESSING,pm_PROCESSING_YIELD,AVP3,0,0)))
				BAvpCancelProcessObject(1);

			break;
#endif//PRAGUE
#ifdef FPIAPI_VER_MAJOR
		case FS_FPI:
			seek=FPI_IO->fFnSetPos((FPIFILEHANDLE)tFile->Handle,sector & CSECT_MASK,SEEK_SET);
			if(seek==(DWORD)-1)
				ok=0;
			readed = FPI_IO->fFnRead((FPIFILEHANDLE)tFile->Handle,data,CSECT_SIZE,&cblock->count);
			_QueryAbort(0);
			break;
#endif//FPIAPI_VER_MAJOR
		default:
			ok =0;
			break;
		}
		
#ifdef	_DEBUG
		if(ok && readed){
			tFile->ReadBlockBytes+=cblock->count;
			tFile->ReadBlock++;
		}
#endif
		

		if(!dirty) ok = ok && readed;
		cblock->sector = sector;
		cblock->tFile = tFile;
    }
    cblock->sector |= dirty;
	if(dirty)cblock->count=CSECT_SIZE;
	if(count)*count=cblock->count;

	LeaveCriticalSection(&csCacheData);
	
    return ok?data:NULL;
}

static int FileFlush( TFileData* tFile, BOOL permanent)
{
    tCACHE_TAG *cblock;
    tCACHE_TAG *sblock;
    BYTE* data;
    int ok = 1;
	if(!CACHE_DATA || tFile==NULL) return 0;

	EnterCriticalSection(&csCacheData);

    cblock = CACHE_DATA->Head;
    while ( cblock && cblock->tFile ) //this is ok, all blocks after should be free.
    {
		int move=0;
		if( cblock->tFile == tFile )
		{
			if(tFile->CurrLen > (cblock->sector & CSECT_MASK))
			{
				if( (cblock->sector & CDIRTY) && ok)
				{
					UINT size=tFile->CurrLen - (cblock->sector & CSECT_MASK);
					if(size>CSECT_SIZE) size=CSECT_SIZE;

					data = cblock->data;

					switch(tFile->HandleFS)
					{
					case FS_WIN32:
						AVPDEF(SetFilePointer)(tFile->Handle,cblock->sector & CSECT_MASK,0,SEEK_SET);
						ok = ok & AVPDEF(WriteFile)(tFile->Handle,data,size,&cblock->count,0);
						ok = ok & (size == cblock->count);
						break;
#ifdef PRAGUE
					case FS_PRAGUE:
						ok = ok & PR_SUCC(CALL_IO_SeekWrite((hIO)tFile->Handle,&cblock->count,cblock->sector & CSECT_MASK,data,size));
						ok = ok & (size == cblock->count);
						break;
#endif//PRAGUE
#ifdef FPIAPI_VER_MAJOR
					case FS_FPI:
						FPI_IO->fFnSetPos((FPIFILEHANDLE)tFile->Handle,cblock->sector & CSECT_MASK,SEEK_SET);
						ok = ok & FPI_IO->fFnWrite((FPIFILEHANDLE)tFile->Handle,data,size,&cblock->count);
						ok = ok & (size == cblock->count);
						_QueryAbort(0);
						break;
#endif//FPIAPI_VER_MAJOR
					default:
						ok =0;
						break;
					}
					cblock->sector &= ~CDIRTY;
				}
				if(permanent)
				{
					move=1;
				}
			}
			else 
			{
				move=1;
			}
        }
        sblock = cblock->next;
		if(move){
			cblock->tFile = NULL;
			MoveBlockToTail(cblock);
		}
        cblock = sblock;
    }
	if(!ok) tFile->WriteBackFailed=1;
	LeaveCriticalSection(&csCacheData);
    return ok;
}

static void CacheCleanup()
{
	int i;
    tCACHE_TAG *cblock;
    tCACHE_TAG *pblock=0;
	if(!CACHE_DATA) return;

	EnterCriticalSection(&csCacheData);

    memset(CACHE_DATA, 0, sizeof(tCACHE_DATA));
    CACHE_DATA->Head = CACHE_DATA->TagArray;
	cblock = CACHE_DATA->Head;

	for( i=0;i<CSECTORS;i++)
	{
		cblock->data= CACHE_DATA->CacheData + i*CSECT_SIZE;
		cblock->prev = pblock;
		pblock=cblock;
		cblock++;
		pblock->next = cblock;
	}
	pblock->next = 0;
	CACHE_DATA->Tail=pblock;
	LeaveCriticalSection(&csCacheData);
}

BOOL WINAPI Cache_AvpReadFile (
    HANDLE  hFile,      // handle of file to read
    LPVOID  lpBuffer,   // address of buffer that receives data
    DWORD  nNumberOfBytesToRead,        // number of bytes to read
    LPDWORD  lpNumberOfBytesRead,       // address of number of bytes read
    OVERLAPPED FAR*  lpOverlapped       // address of structure for data BYTE Disk, WORD Sector ,BYTE Head ,LPBYTE Buffer)
        )
{
    BYTE* data;
    UINT  toread;
    UINT  readoff;
	BYTE* buffer=(BYTE*)lpBuffer;
	TFileData* tFile=(TFileData*)hFile;
    if(lpNumberOfBytesRead)
		*lpNumberOfBytesRead = 0;
	if(!TFileData_IsValid(tFile)) return FALSE;

    if (tFile->CurrPos > tFile->CurrLen) 
		nNumberOfBytesToRead=0;
	else if ((tFile->CurrPos + nNumberOfBytesToRead) > tFile->CurrLen)
		nNumberOfBytesToRead = tFile->CurrLen - tFile->CurrPos;

#ifdef	_DEBUG
	tFile->ReadCount++;
#endif
	
    while ( nNumberOfBytesToRead )
    {
		DWORD count;
        readoff = tFile->CurrPos & ~(CSECT_MASK);
        data = (BYTE *)FileSector(tFile,(tFile->CurrPos & CSECT_MASK),&count);
		if(data==NULL){
			return FALSE;
		}
		data += readoff;

#ifdef	_DEBUG
		tFile->ReadBytes+=count;
#endif		
		if ( count <= readoff ) break;
		toread = count - readoff;

//		toread=CSECT_SIZE - readoff;
		
        if ( toread > nNumberOfBytesToRead ) toread = nNumberOfBytesToRead;
        memcpy(buffer,data,toread);

		if(lpNumberOfBytesRead)
			*lpNumberOfBytesRead += toread;
        tFile->CurrPos += toread;
        buffer += toread;
        nNumberOfBytesToRead -= toread;
    }
	
    return TRUE;
}

BOOL  WINAPI Cache_AvpWriteFile (
    HANDLE  hFile,      // handle to file to write to
    LPCVOID  lpBuffer,  // pointer to data to write to file
    DWORD  nNumberOfBytesToWrite,       // number of bytes to write
    LPDWORD  lpNumberOfBytesWritten,    // pointer to number of bytes written
    OVERLAPPED FAR*  lpOverlapped       // addr. of structure needed for overlapped I/O
        )
{
    BYTE* data;
    UINT  toread;
    UINT  readoff;
	BYTE* buffer=(BYTE*)lpBuffer;
	TFileData* tFile=(TFileData*)hFile;
    if(lpNumberOfBytesWritten)
	    *lpNumberOfBytesWritten = 0;
	if(!TFileData_IsValid(tFile)) return FALSE;

    while ( nNumberOfBytesToWrite )
    {
        readoff = tFile->CurrPos & ~(CSECT_MASK);
        toread  = CSECT_SIZE - readoff;
        data = (BYTE *)FileSector(tFile,(tFile->CurrPos & CSECT_MASK) | 1 , NULL);
		if(data==NULL){
			return FALSE;
		}
		data += readoff;
        if ( toread > nNumberOfBytesToWrite ) toread = nNumberOfBytesToWrite;
        memcpy(data,buffer,toread);

	    if(lpNumberOfBytesWritten)
			*lpNumberOfBytesWritten += toread;
        tFile->CurrPos += toread;
        buffer += toread;
        nNumberOfBytesToWrite -= toread;
		if(tFile->CurrPos > tFile->CurrLen)
		{
			tFile->SetEOF=1;
			tFile->CurrLen=tFile->CurrPos;
		}
    }

	if(!tFile->Changed){
		tFile->Changed=1;

		if(!FileFlush(tFile,FALSE))
		{
		    if(lpNumberOfBytesWritten)
				*lpNumberOfBytesWritten = 0;
			return FALSE;
		}
	}
    return TRUE;
}

#ifdef PRAGUE
extern "C" hIO PgOpenIO(void* ptr, DWORD openMode, DWORD  dwFlagsAndAttributes);
extern "C" BOOL PgDeleteIO(void* ptr);
#endif

BOOL  WINAPI Cache_AvpDeleteFile (
    LPCTSTR  lpFileName        // pointer to name of the file
	)
{
#ifdef PRAGUE
	if(PgDeleteIO((void*)lpFileName))
		return TRUE;
	else
#endif//PRAGUE
		return AVPDEF(DeleteFile)(lpFileName);
}

HANDLE  WINAPI Cache_AvpCreateFile (
    LPCTSTR  lpFileName,        // pointer to name of the file
    DWORD  dwDesiredAccess,     // access (read-write) mode
    DWORD  dwShareMode, // share mode
    SECURITY_ATTRIBUTES FAR*  lpSecurityAttributes,     // pointer to security descriptor
    DWORD  dwCreationDistribution,      // how to create
    DWORD  dwFlagsAndAttributes,        // file attributes
    HANDLE  hTemplateFile       // handle to file with attributes to copy
        )
{
    TFileData * fd = TFileData_New();
	if(!fd) return INVALID_HANDLE_VALUE;

	dwDesiredAccess|=GENERIC_READ;

#ifdef PRAGUE
	
#ifdef INTERLOCK
		InterlockedIncrement(&InMyOpenClose);
#endif
	fd->Handle=(HANDLE)PgOpenIO((void*)lpFileName, dwDesiredAccess, dwFlagsAndAttributes);
#ifdef INTERLOCK
		InterlockedDecrement(&InMyOpenClose);
#endif
	if( fd->Handle )
	{
		fd->HandleFS = FS_PRAGUE;
		CALL_IO_Size((hIO)fd->Handle,&fd->CurrLen,IO_SIZE_TYPE_EXPLICIT);
#ifdef _DEBUG
//		sprintf(fd->Name,"PRAGUE handle 0x%08X %s",fd->Handle,lpFileName);
#endif
		switch(dwCreationDistribution)
		{
		case CREATE_ALWAYS:
		case TRUNCATE_EXISTING:
			Cache_AvpSetFilePointer(fd,0,NULL,FILE_BEGIN);
			Cache_AvpSetEndOfFile(fd);
		default:
			break;
		}
	
		goto opened;
	}
#endif//PRAGUE

#ifdef FPIAPI_VER_MAJOR
	_QueryAbort(0);
	if(FPI_IO)
	{
		int access_=0; //!!!!
		switch(dwDesiredAccess)
		{
		default:
		case 0:
		case GENERIC_READ:
			access_=FPIFILEIO_READ;
			break;
		case GENERIC_WRITE:
			access_=FPIFILEIO_WRITE;
			break;
		case GENERIC_WRITE | GENERIC_READ:
			access_=FPIFILEIO_RDWR;
			break;
		}
		switch(dwCreationDistribution){
		case CREATE_NEW:
		case CREATE_ALWAYS:
			access_=FPIFILEIO_CREATE;
		default:
			break;
		}
		
		FPIFILEHANDLE fh=FPI_IO->fFnOpen(fpiParentGet(lpFileName),lpFileName,access_,	
			open_reserved_flag,0,0);

		if(fh!=FPIFILEHANDLE_ERROR)
		{
			fd->Handle=(HANDLE)fh;
			fd->HandleFS = FS_FPI;
			fd->CurrLen=FPI_IO->fFnGetSize((FPIFILEHANDLE)fd->Handle);
#ifdef _DEBUG
		sprintf(fd->Name,"FPI handle 0x%08X %s",fd->Handle,lpFileName);
#endif
			goto opened;
		}
	}
#endif//FPIAPI_VER_MAJOR

	{
#ifdef INTERLOCK
		InterlockedIncrement(&InMyOpenClose);
#endif
		fd->Handle = AVPDEF(CreateFile) (  lpFileName, dwDesiredAccess, dwShareMode, 
			lpSecurityAttributes, dwCreationDistribution, dwFlagsAndAttributes, hTemplateFile);
#ifdef INTERLOCK
		InterlockedDecrement(&InMyOpenClose);
#endif

		if (fd->Handle==INVALID_HANDLE_VALUE){
			delete fd;
			return INVALID_HANDLE_VALUE;
		}
		fd->HandleFS=FS_WIN32;
		fd->CurrLen=AVPDEF(GetFileSize)(fd->Handle,0);

#ifdef _DEBUG
		strcpy(fd->Name,lpFileName);
#endif
		goto opened;
	}

opened:
	return (HANDLE)fd;
}

BOOL  WINAPI Cache_AvpCloseHandle(
    HANDLE  hObject     // handle to object to close
        )
{
	BOOL ok;
	TFileData* tFile=(TFileData*)hObject;
	if(!TFileData_IsValid(tFile)) return FALSE;
	ok  = FileFlush(tFile,TRUE);

	switch(tFile->HandleFS)
	{
	case FS_WIN32:
		if(tFile->SetEOF){
			ok = ok & (tFile->CurrLen == AVPDEF(SetFilePointer)(tFile->Handle,tFile->CurrLen,0,SEEK_SET));
			ok = ok & AVPDEF(SetEndOfFile)(tFile->Handle);
		}
#ifdef INTERLOCK
		InterlockedIncrement(&InMyOpenClose);
#endif
		ok = ok & AVPDEF(CloseHandle)(tFile->Handle);
#ifdef INTERLOCK
		InterlockedDecrement(&InMyOpenClose);
#endif
		break;
#ifdef PRAGUE
	case FS_PRAGUE:
		if(tFile->SetEOF){
			ok = ok & PR_SUCC(CALL_IO_Resize((hIO)tFile->Handle,NULL,tFile->CurrLen));
		}
		break;
#endif//PRAGUE
#ifdef FPIAPI_VER_MAJOR
	case FS_FPI:
		if(tFile->SetEOF){
			ok = ok & (tFile->CurrLen == FPI_IO->fFnSetPos((FPIFILEHANDLE)tFile->Handle,tFile->CurrLen,SEEK_SET));
			ok = ok & FPI_IO->fFnSetEnd((FPIFILEHANDLE)tFile->Handle);
		}
		ok = ok & FPI_IO->fFnClose((FPIFILEHANDLE)tFile->Handle);
		_QueryAbort(0);
		break;
#endif//FPIAPI_VER_MAJOR
	default:
		break;
	}

	TFileData_Remove(tFile);
	return ok;
}

DWORD  WINAPI Cache_AvpSetFilePointer(
    HANDLE  hFile,      // handle of file
    LONG  lDistanceToMove,      // number of bytes to move file pointer
    PLONG  lpDistanceToMoveHigh,        // address of high-order word of distance to move
    DWORD  dwMoveMethod         // how to move
        )
{
	TFileData* tFile=(TFileData*)hFile;
	if(!TFileData_IsValid(tFile)) return (DWORD)-1;

	switch(dwMoveMethod)
	{
	case SEEK_SET:
		if(lDistanceToMove<0) 
			return (DWORD)-1;
		tFile->CurrPos=lDistanceToMove; break;

	case SEEK_CUR:
		if(lDistanceToMove<0)
		{
			if(tFile->CurrPos < (DWORD)(-lDistanceToMove))
				return (DWORD)-1;
		}else{
			if(tFile->CurrPos + lDistanceToMove < tFile->CurrPos) 
				return (DWORD)-1;
		}
		tFile->CurrPos+=lDistanceToMove; break;

	case SEEK_END:
		if(lDistanceToMove<0)
		{
			if(tFile->CurrLen < (DWORD)(-lDistanceToMove))
				return (DWORD)-1;
		}else{
			if(tFile->CurrLen + lDistanceToMove < tFile->CurrLen) 
				return (DWORD)-1;
		}
		tFile->CurrPos=tFile->CurrLen+lDistanceToMove; break;
	
	default:
		return (DWORD)-1;
	}

	return tFile->CurrPos;
}

BOOL  WINAPI Cache_AvpSetEndOfFile(
    HANDLE  hFile       // handle of file
        )
{
	BOOL ok =1;
	TFileData* tFile=(TFileData*)hFile;
	if(!TFileData_IsValid(tFile)) return FALSE;
	tFile->SetEOF=1;
	tFile->CurrLen=tFile->CurrPos;
	ok  = FileFlush(tFile,FALSE);

	switch(tFile->HandleFS)
	{
	case FS_WIN32:
		if(tFile->SetEOF){
			DWORD a=AVPDEF(SetFilePointer)(tFile->Handle,tFile->CurrLen,0,SEEK_SET);
			ok = ok & (tFile->CurrLen == a);
			ok = ok & AVPDEF(SetEndOfFile)(tFile->Handle);
		}
		break;
#ifdef PRAGUE
	case FS_PRAGUE:
		if(tFile->SetEOF){
			ok = ok & PR_SUCC(CALL_IO_Resize((hIO)tFile->Handle,NULL,tFile->CurrLen));
		}
		break;
#endif//PRAGUE
#ifdef FPIAPI_VER_MAJOR
	case FS_FPI:
		if(tFile->SetEOF){
			ok = ok & (tFile->CurrLen == FPI_IO->fFnSetPos((FPIFILEHANDLE)tFile->Handle,tFile->CurrLen,SEEK_SET));
			ok = ok & FPI_IO->fFnSetEnd((FPIFILEHANDLE)tFile->Handle);
		}
		_QueryAbort(0);
		break;
#endif//FPIAPI_VER_MAJOR
	default:
		break;
	}

	return ok;
}

DWORD WINAPI Cache_AvpGetFileSize(
    HANDLE  hFile,      // handle of file
    LPDWORD  lpHigh
        )
{
	TFileData* tFile=(TFileData*)hFile;
	if(!TFileData_IsValid(tFile)) return (DWORD)-1;
	return tFile->CurrLen;
}

BOOL WINAPI AvpFlush(
    HANDLE  hFile       // handle of file
        )
{
	return 1;
}

BOOL WINAPI Cache_AvpFlush(
    HANDLE  hFile       // handle of file
        )
{
	BOOL ret;
	TFileData* tFile=(TFileData*)hFile;
	if(!TFileData_IsValid(tFile)) return FALSE;
	ret  = FileFlush(tFile,FALSE);
	return ret;
}

extern "C" int Cache_Destroy(void)
{
	if(!CACHE_DATA) return 0;
	EnterCriticalSection(&csCacheData);
	DupFree(CACHE_DATA);
	CACHE_DATA=0;
	LeaveCriticalSection(&csCacheData);
	DeleteCriticalSection(&csCacheData);
	return 1;
}

extern "C" int Cache_Init(void)
{
	if (CACHE_DATA==0)
	{
		CACHE_DATA= (tCACHE_DATA*) DupAlloc(sizeof(tCACHE_DATA),1);
		if (CACHE_DATA==0)
			return 0;
		InitializeCriticalSection(&csCacheData);
		CacheCleanup();
	}
	return 1;
}

