typedef struct TFileData_
{
    ULONG                   CurrPos;
    ULONG                   CurrLen;
	BOOL					SetEOF;
	BOOL					Changed;
	BOOL					WriteBackFailed;
	
    HANDLE                  Handle;
	ULONG                   HandleFS;

	DWORD                   Signature;

#ifdef _DEBUG
	char					Name[512];
	DWORD                   ReadCount;
	DWORD                   ReadBytes;
	DWORD                   ReadBlock;
	DWORD                   ReadBlockBytes;
#endif
}TFileData;

//fHandleFS defines
#define FS_PRAGUE  0
#define FS_WIN32   1
#define FS_FPI     2

